package com.example.converter.controller;

import com.example.converter.dto.ConversionResponse;
import com.example.converter.service.CurrencyService;
import org.springframework.web.bind.annotation.*;
import reactor.core.publisher.Mono;
import org.springframework.http.ResponseEntity;

@RestController
@RequestMapping("/convert")
public class ConverterController {

    private final CurrencyService currencyService;

    public ConverterController(CurrencyService currencyService) {
        this.currencyService = currencyService;
    }

    @GetMapping
    public Mono<ResponseEntity<ConversionResponse>> convertCurrency(
            @RequestParam String from,
            @RequestParam String to,
            @RequestParam double amount) {

        return currencyService.convert(from, to, amount)
                .map(ResponseEntity::ok)
                .onErrorResume(e -> Mono.just(ResponseEntity.badRequest().body(null)));
    }
}