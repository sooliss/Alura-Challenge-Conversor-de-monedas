package com.example.converter.dto;

import java.time.LocalDateTime;

public class ConversionResponse {
    private final String from;
    private final String to;
    private final double amount;
    private final double result;
    private final LocalDateTime date;

    public ConversionResponse(String from, String to, double amount, double result, LocalDateTime date) {
        this.from = from;
        this.to = to;
        this.amount = amount;
        this.result = result;
        this.date = date;
    }

    public String getFrom() { return from; }
    public String getTo() { return to; }
    public double getAmount() { return amount; }
    public double getResult() { return result; }
    public LocalDateTime getDate() { return date; }
}