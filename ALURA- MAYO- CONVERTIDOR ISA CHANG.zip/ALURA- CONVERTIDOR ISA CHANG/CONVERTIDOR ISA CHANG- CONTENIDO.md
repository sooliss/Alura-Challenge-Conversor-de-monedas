# 💸 Convertidor de Monedas - Isa Chang

Este es un conversor de monedas hecho en Java usando Spring Boot. Utiliza una API pública para obtener las tasas de cambio en tiempo real.

## 🔧 Tecnologías usadas

- Java 17
- Spring Boot 3.x
- WebClient
- ExchangeRate-API (gratis)

## 📥 Endpoints

GET `/convert?from=USD&to=EUR&amount=100`

## 📦 Ejecutar el proyecto

1. Clona el repositorio.
2. Asegúrate de tener JDK 17+ instalado.
3. Usa Maven para ejecutar:
   ```bash
   mvn spring-boot:run