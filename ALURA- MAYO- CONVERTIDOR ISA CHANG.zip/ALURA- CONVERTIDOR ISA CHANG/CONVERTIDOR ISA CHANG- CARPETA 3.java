package com.example.converter.service;

import com.example.converter.dto.ConversionResponse;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import java.time.LocalDateTime;
import java.util.Map;

@Service
public class CurrencyService {

    private final WebClient webClient = WebClient.builder()
            .baseUrl("https://api.exchangerate-api.com/v4/latest/ ")
            .build();

    public Mono<ConversionResponse> convert(String from, String to, double amount) {
        return webClient.get()
                .uri(from)
                .retrieve()
                .bodyToMono(RateResponse.class)
                .map(rateResponse -> {
                    Double rate = rateResponse.rates().get(to.toUpperCase());
                    if (rate == null) {
                        throw new IllegalArgumentException("Moneda destino no soportada: " + to);
                    }
                    double result = amount * rate;
                    return new ConversionResponse(
                            from.toUpperCase(),
                            to.toUpperCase(),
                            amount,
                            result,
                            LocalDateTime.parse(rateResponse.updated())
                    );
                });
    }

    // Clase interna para mapear la respuesta de la API
    private record RateResponse(Map<String, Double> rates, String updated) {}
}